
<a href="javascript:void(0)" class="btn btn-primary btn-sm edit-currency" 
   data-bs-toggle="modal" 
   data-bs-target="#currencyModal" 
   data-id="{{ $id }}" 
   data-mode="edit">
    <i class="fas fa-edit"></i>
</a>
