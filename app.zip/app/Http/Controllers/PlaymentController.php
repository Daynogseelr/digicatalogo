<?php

namespace App\Http\Controllers;
use App\Models\Playment;
use Illuminate\Http\Request;

class PlaymentController extends Controller
{
    public function playmentClient(Request $request)
    {
        $request->validate([
            'type' => 'required|min:2|max:100|string',
            'bank'  => 'required|min:2|max:100|string',
            'reference'  => 'required|string',
            'amount'  => 'required|numeric|min:1|max:99999999999',
            'capture'  => 'required|image|max:2048',
        ]);
        $ruta = 'payments/';
        $imagenCapture = date('YmdHis') . "." . $request->capture->getClientOriginalExtension();
        $request->capture->move($ruta, $imagenCapture);
        $urlCapture = $imagenCapture;
        $playment = Playment::Create(
            [
                'id_cart' => $request->id_playment_cart,
                'type' => $request->type,
                'bank' => $request->bank,
                'reference' => $request->reference,
                'amount' => $request->amount,
                'capture' => $urlCapture
            ]
        );
        return Response()->json($playment);
    }
    
    public function verPlaymentClient(Request $request)
    {
        $playment = Playment::where('id_cart',$request->id)->first();
        return Response()->json($playment);
    }
}
