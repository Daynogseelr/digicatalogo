<!DOCTYPE html>
<html>
<head>
    <title>Product PDF</title>
    <style>
         body {
            font-family: sans-serif;
 /* Tamaño de fuente para todo el documento */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 8pt; 
        }
        th, td {
            border: 1px solid black;
            padding: 2px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .total {
            font-weight: bold;
            margin-bottom: 20px; /* Add some spacing below the total */
        }
        .filter-type {
            margin-bottom: 20px;
        }
        .text-center {
            text-align: center;
        }
        .text-end {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="filter-type">
        <strong>Filter Type:</strong> {{ $type }}
    </div>
    <div class="total">
        Total: {{ number_format($total, 2, '.', '') }}
    </div>
    <table>
        <thead>
            <tr>
                <th class="text-center">Fecha</th>
                <th class="text-center">Codigo</th>
                <th class="text-center">Nombre</th>
                <th class="text-center">Precio</th>
                <th class="text-center">Cantidad</th>
                <th class="text-center">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach($products as $product)
                <tr>
                    <td class="text-center">{{ $product->created_at ? $product->created_at->format('d/m/Y H:i:s') : '' }}</td>
                    <td class="text-center">{{ $product->code }}</td>
                    <td>{{ $product->name }}</td>
                    <td class="text-end">{{ number_format($product->price, 2, '.', '') }}</td>
                    <td class="text-center">{{ $product->quantity }}</td>
                    <td class="text-end">{{ number_format(($product->quantity ?? 0) * $product->price, 2, '.', '') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
