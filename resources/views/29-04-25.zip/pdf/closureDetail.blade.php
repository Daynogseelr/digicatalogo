<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cierre Detallado</title>
    <style>
        body {
            font-family: sans-serif;
            font-size: 10pt; /* Tamaño de fuente para todo el documento */
            width: 700px;
            margin: -50px 0px -50px -40px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header p {
            margin: 2px 0; /* Espacio entre las líneas del encabezado */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 5px;
            text-align: left;
            font-size: 8pt; /* Tamaño de fuente para la tabla */
        }
        th {
            background-color: #f2f2f2;
        }
        .footer {
            text-align: right;
            font-style: italic;
        }
        @page {
            size: letter; /* Define el tamaño de la página a carta */
            margin: 1in; /* Margen de 1 pulgada en todos los lados */
        }
    </style>
</head>
<body>
    <div class="header">
        {{--<p>{{$closure->companyNationality}}-{{$closure->companyCi}}</p>
        <p>{{$closure->companyName}}</p>
         <p>{{$closure->companyDirection}}</p>
        <p>{{$closure->companyCity}} EDO. {{$closure->companyState}} ZONA POSTAL {{$closure->companyPostal_zone}}</p> --}}
    </div>
    <div>
        <span><b>Generado por:</b> {{$closure->sellerName}} {{$closure->sellerLast_name}}</span>
        <span style="float: right;"><b></b></span>
        <div style="clear: both;"></div>  
    </div>
    <br>
    <h3 style="text-align: center;">FACTURACIÓN</h3>  
    @if (!empty($billBs))
        @foreach ($billBs as $billB)
            <table>
                <thead>
                    <tr>
                        <th colspan='6'  style="text-align: center;">{{$billB->type }} Bs.</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Código</th>
                        <th style="text-align: center;">Empleado</th>
                        <th style="text-align: center;">Cliente</th>
                        <th style="text-align: center;">Total</th>
                        <th style="text-align: center;">Descuento</th>
                        <th style="text-align: center;">Total Neto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($typebillBs as $typebillB)
                        @if ($billB->type == $typebillB->type)
                            <tr>
                                <td style="text-align: center;">{{$typebillB->code}}</td>
                                <td>{{$typebillB->seller->name}} {{$typebillB->seller->last_name}}</td>
                                <td>{{$typebillB->client->name}} {{$typebillB->client->last_name}}</td>
                                <td style="text-align: right;">{{$typebillB->total_amountBs}}</td>
                                <td style="text-align: right;">{{$typebillB->discountBs}}</td>
                                <td style="text-align: right;">{{$typebillB->net_amountBs}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='5' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$billB->net_amountBs}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach 
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='6'  style="text-align: center;">BOLIVARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Código</th>
                    <th style="text-align: center;">Empleado</th>
                    <th style="text-align: center;">Cliente</th>
                    <th style="text-align: center;">Total</th>
                    <th style="text-align: center;">Descuento</th>
                    <th style="text-align: center;">Total Neto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='6' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>
    @endif
    @if (!empty($bills))
        @foreach ($bills as $bill)
            <table>
                <thead>
                    <tr>
                        <th colspan='6' style="text-align: center;">{{$bill->type }} $</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Código</th>
                        <th style="text-align: center;">Empleado</th>
                        <th style="text-align: center;">Cliente</th>
                        <th style="text-align: center;">Total</th>
                        <th style="text-align: center;">Descuento</th>
                        <th style="text-align: center;">Total Neto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($typebills as $typebill)
                        @if ($bill->type == $typebill->type)
                            <tr>
                                <td style="text-align: center;">{{$typebill->code}}</td>
                                <td>{{$typebill->seller->name}} {{$typebill->seller->last_name}}</td>
                                <td>{{$typebill->client->name}} {{$typebill->client->last_name}}</td>
                                <td style="text-align: right;">{{$typebill->total_amount}}</td>
                                <td style="text-align: right;">{{$typebill->discount}}</td>
                                <td style="text-align: right;">{{$typebill->net_amount}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='5' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$bill->net_amount}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach    
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='6'  style="text-align: center;">DOLARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Código</th>
                    <th style="text-align: center;">Empleado</th>
                    <th style="text-align: center;">Cliente</th>
                    <th style="text-align: center;">Total</th>
                    <th style="text-align: center;">Descuento</th>
                    <th style="text-align: center;">Total Neto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='6' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>
    @endif
    <h3 style="text-align: center;">PAGOS</h3>  
    @if (!empty($bill_paymentContadoBs))
        @foreach ($bill_paymentContadoBs as $bill_paymentContadoB)
            <table>
                <thead>
                    <tr>
                        <th colspan='5'  style="text-align: center;">{{$bill_paymentContadoB->type }} Bs.</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Factura</th>
                        <th style="text-align: center;">Empleado</th>
                        <th style="text-align: center;">Cliente</th>
                        <th style="text-align: center;">Referencia</th>
                        <th style="text-align: center;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($typebill_paymentContadoBs as $typebill_paymentContadoB)
                        @if ($bill_paymentContadoB->type == $typebill_paymentContadoB->type)
                            <tr>
                                <td style="text-align: center;">{{$typebill_paymentContadoB->bill->code}}</td>
                                <td>{{$typebill_paymentContadoB->bill->seller->name}} {{$typebill_paymentContadoB->bill->seller->last_name}}</td>
                                <td>{{$typebill_paymentContadoB->bill->client->name}} {{$typebill_paymentContadoB->bill->client->last_name}}</td>
                                <td>{{$typebill_paymentContadoB->reference}}</td>
                                <td style="text-align: right;">{{$typebill_paymentContadoB->amountBs}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='4' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$bill_paymentContadoB->amountBs}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach  
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='5'  style="text-align: center;">BOLIVARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Factura</th>
                    <th style="text-align: center;">Empleado</th>
                    <th style="text-align: center;">Cliente</th>
                    <th style="text-align: center;">Referencia</th>
                    <th style="text-align: center;">Monto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='5' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>
    @endif
    @if (!empty($bill_paymentContado))
         @foreach ($bill_paymentContado as $bill_paymentContad)
            <table>
                <thead>
                    <tr>
                        <th colspan='5'  style="text-align: center;">{{$bill_paymentContad->type }} $</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Factura</th>
                        <th style="text-align: center;">Empleado</th>
                        <th style="text-align: center;">Cliente</th>
                        <th style="text-align: center;">Referencia</th>
                        <th style="text-align: center;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($typebill_paymentContado as $typebill_paymentContad)
                        @if ($bill_paymentContad->type == $typebill_paymentContad->type)
                            <tr>
                                <td style="text-align: center;">{{$typebill_paymentContad->bill->code}}</td>
                                <td>{{$typebill_paymentContad->bill->seller->name}} {{$typebill_paymentContad->bill->seller->last_name}}</td>
                                <td>{{$typebill_paymentContad->bill->client->name}} {{$typebill_paymentContad->bill->client->last_name}}</td>
                                <td>{{$typebill_paymentContad->reference}}</td>
                                <td style="text-align: right;">{{$typebill_paymentContad->amount}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='4' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$bill_paymentContad->amount}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='5'  style="text-align: center;">DOLARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Factura</th>
                    <th style="text-align: center;">Empleado</th>
                    <th style="text-align: center;">Cliente</th>
                    <th style="text-align: center;">Referencia</th>
                    <th style="text-align: center;">Monto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='5' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>  
    @endif
    <h3 style="text-align: center;">COBRANZAS</h3> 
    @if (!empty($bill_paymentCreditoBs))
         @foreach ($bill_paymentCreditoBs as $bill_paymentCreditoB)
            <table>
                <thead>
                    <tr>
                        <th colspan='5'  style="text-align: center;">{{$bill_paymentCreditoB->type }} Bs.</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Factura</th>
                        <th style="text-align: center;">Empleado</th>
                        <th style="text-align: center;">Cliente</th>
                        <th style="text-align: center;">Referencia</th>
                        <th style="text-align: center;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($typebill_paymentCreditoBs as $typebill_paymentCreditoB)
                        @if ($bill_paymentCreditoB->type == $typebill_paymentCreditoB->type)
                            <tr>
                                <td style="text-align: center;">{{$typebill_paymentCreditoB->bill->code}}</td>
                                <td>{{$typebill_paymentCreditoB->bill->seller->name}} {{$typebill_paymentCreditoB->bill->seller->last_name}}</td>
                                <td>{{$typebill_paymentCreditoB->bill->client->name}} {{$typebill_paymentCreditoB->bill->client->last_name}}</td>
                                <td>{{$typebill_paymentCreditoB->reference}}</td>
                                <td style="text-align: right;">{{$typebill_paymentCreditoB->amountBs}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='4' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$bill_paymentCreditoB->amountBs}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='5'  style="text-align: center;">BOLIVARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Factura</th>
                    <th style="text-align: center;">Empleado</th>
                    <th style="text-align: center;">Cliente</th>
                    <th style="text-align: center;">Referencia</th>
                    <th style="text-align: center;">Monto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='5' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>
    @endif
    @if (!empty($bill_paymentCredito))
        @foreach ($bill_paymentCredito as $bill_paymentCredit)
            <table>
                <thead>
                    <tr>
                        <th colspan='5'  style="text-align: center;">{{$bill_paymentCredit->type }} $</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Factura</th>
                        <th style="text-align: center;">Empleado</th>
                        <th style="text-align: center;">Cliente</th>
                        <th style="text-align: center;">Referencia</th>
                        <th style="text-align: center;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($typebill_paymentCredito as $typebill_paymentCredit)
                        @if ($bill_paymentCredit->type == $typebill_paymentCredit->type)
                            <tr>
                                <td style="text-align: center;">{{$typebill_paymentCredit->bill->code}}</td>
                                <td>{{$typebill_paymentCredit->bill->seller->name}} {{$typebill_paymentCredit->bill->seller->last_name}}</td>
                                <td>{{$typebill_paymentCredit->bill->client->name}} {{$typebill_paymentCredit->bill->client->last_name}}</td>
                                <td>{{$typebill_paymentCredit->reference}}</td>
                                <td style="text-align: right;">{{$typebill_paymentCredit->amount}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='4' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$bill_paymentCredit->amount}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='5'  style="text-align: center;">DOLARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Factura</th>
                    <th style="text-align: center;">Empleado</th>
                    <th style="text-align: center;">Cliente</th>
                    <th style="text-align: center;">Referencia</th>
                    <th style="text-align: center;">Monto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='5' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>
    @endif 
    <h3 style="text-align: center;">DEVOLUCIONES</h3> 
    @if (!empty($repaymentBs))
        @foreach ($repaymentBs as $repaymentB)
            @php
                if ($repaymentB->status == 0 ) {
                    $status = 'NOTA DE CREDITO';
                } else {
                    $status = 'DEVOLUCIÓN';
                }
            @endphp
            <table>
                <thead>
                    <tr>
                        <th colspan='5'  style="text-align: center;">{{$status}} Bs.</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Factura</th>
                        <th style="text-align: center;">Codigo</th>
                        <th style="text-align: center;">Producto</th>
                        <th style="text-align: center;">Cantidad</th>
                        <th style="text-align: center;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($statusrepaymentBs as $statusrepaymentB)
                        @if ($repaymentB->status == $statusrepaymentB->status)
                            <tr>
                                <td style="text-align: center;">{{$statusrepaymentB->bill->code}}</td>
                                <td style="text-align: center;">{{$statusrepaymentB->code}}</td>
                                <td>{{$statusrepaymentB->product->code}}-{{$statusrepaymentB->product->name}}</td>
                                <td style="text-align: center;">{{$statusrepaymentB->quantity}}</td>
                                <td style="text-align: right;">{{$statusrepaymentB->amountBs}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='4' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$repaymentB->amountBs}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach 
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='5'  style="text-align: center;">BOLIVARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Factura</th>
                    <th style="text-align: center;">Codigo</th>
                    <th style="text-align: center;">Producto</th>
                    <th style="text-align: center;">Cantidad</th>
                    <th style="text-align: center;">Monto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='5' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>
    @endif 
    @if (!empty($repayments))
        @foreach ($repayments as $repayment)
            @php
                if ($repayment->status == 0 ) {
                    $status = 'NOTA DE CREDITO';
                } else {
                    $status = 'DEVOLUCIÓN';
                }
            @endphp
            <table>
                <thead>
                    <tr>
                        <th colspan='5'  style="text-align: center;">{{$status}} $</th>
                    </tr>
                    <tr>
                        <th style="text-align: center;">Factura</th>
                        <th style="text-align: center;">Codigo</th>
                        <th style="text-align: center;">Producto</th>
                        <th style="text-align: center;">Cantidad</th>
                        <th style="text-align: center;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($statusrepayment as $statusrepaymen)
                        @if ($repayment->status == $statusrepaymen->status)
                            <tr>
                                <td style="text-align: center;">{{$statusrepaymen->bill->code}}</td>
                                <td style="text-align: center;">{{$statusrepaymen->code}}</td>
                                <td>{{$statusrepaymen->product->code}}-{{$statusrepaymen->product->name}}</td>
                                <td style="text-align: center;">{{$statusrepaymen->quantity}}</td>
                                <td style="text-align: right;">{{$statusrepaymen->amount}}</td>
                            </tr>
                        @endif
                    @endforeach
                    <tr>
                        <td colspan='4' style="text-align: right;"><b>TOTAL</b></td>
                        <td style="text-align: right;"><b>{{$repayment->amount}}</b></td>
                    </tr>
                </tbody>
            </table>
            <br>
        @endforeach
    @else
        <table>
            <thead>
                <tr>
                    <th colspan='5'  style="text-align: center;">DOLARES</th>
                </tr>
                <tr>
                    <th style="text-align: center;">Factura</th>
                    <th style="text-align: center;">Codigo</th>
                    <th style="text-align: center;">Producto</th>
                    <th style="text-align: center;">Cantidad</th>
                    <th style="text-align: center;">Monto</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan='5' style="text-align: center;">No hay datos en esta tabla</td>
                </tr>
            </tbody>
        </table>
        <br>
    @endif 
    <div class="footer">
        <p>Fecha de Generación: <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>
</body>
</html>