<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cierre</title>
    <style>
        @page {
            size: 80mm auto;
            margin: 10px;
            margin-left: 20px;
        }
        body {
            font-family: Arial, sans-serif;
            font-size: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            
        }

        th, td {
            
            padding: 2px;
            text-align: left;
        }

        .titulo {
            text-align: center;
            font-weight: bold;
        }
        .center {
            text-align: center;
        }
        .nota {
            font-size: 8px;
        }
        .end{
            text-align: right;
        }
        .puntos{
            padding: 0px;
        }
        .size{
            font-size: 12px;
        }
    </style>
</head>
<body>
    <table width="100%">
        {{-- <tr>
            <td colspan="4" class="titulo">{{$closure->companyNationality}}-{{$closure->companyCi}}</td>
        </tr>
        <tr>
            <td colspan="4" class="titulo">{{$closure->companyName}}</td>
        </tr>
        <tr>
            <td colspan="4" class="center">{{$closure->companyDirection}}</td>
        </tr>
        <tr>
            <td colspan="4"  class="center">{{$closure->companyCity}} EDO. {{$closure->companyState}} ZONA POSTAL {{$closure->companyPostal_zone}}</td>
        </tr> --}}
        <tr>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td colspan="4"><b>Vendedor:</b> {{$closure->sellerName}} {{$closure->sellerLast_name}}</td>
        </tr>
        <tr>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td colspan="4" class="center"><b>CIERRE</b></td>
        </tr>
        <tr>
            <td colspan="2"><b>FECHA:</b> {{$closure->date}}</td>
            <td colspan="2" class="end"><b>HORA:</b> {{$closure->time}}</td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>FACTURACIÓN</b></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>BOLIVARES</b></td>
        </tr>
        @php
            $totalBillBs = 0;
        @endphp
        @foreach ($billBs as $billB)
            <tr>
                <td colspan="2"><b>{{$billB->type}}</b></td>
                <td colspan="2" class="end">{{ number_format($billB->net_amountBs, 2)}}</td>
            </tr>
            @php
                $totalBillBs = $totalBillBs + $billB->net_amountBs;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{ number_format($totalBillBs, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4" class="center"><b>DOLARES</b></td>
        </tr>
        @php
            $totalBill = 0;
        @endphp
        @foreach ($bills as $bill)
            <tr>
                <td colspan="2"><b>{{$bill->type}}</b></td>
                <td colspan="2" class="end">{{number_format($bill->net_amount, 2) }}</td>
            </tr>
            @php
                $totalBill = $totalBill + $bill->net_amount;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{number_format($totalBill, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>PAGOS</b></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>BOLIVARES</b></td>
        </tr>
        @php
            $totalBill_paymentBs = 0;
        @endphp
        @foreach ($bill_paymentContadoBs as $bill_paymentB)
            <tr>
                <td colspan="2"><b>{{$bill_paymentB->type}}</b></td>
                <td colspan="2" class="end">{{number_format($bill_paymentB->amountBs, 2)}}</td>
            </tr>
            @php
                $totalBill_paymentBs = $totalBill_paymentBs + $bill_paymentB->amountBs;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{number_format($totalBill_paymentBs, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4" class="center"><b>DOLARES</b></td>
        </tr>
        @php
            $totalBill_payment = 0;
        @endphp
        @foreach ($bill_paymentsContado as $bill_payment)
            <tr>
                <td colspan="2"><b>{{$bill_payment->type}}</b></td>
                <td colspan="2" class="end">{{number_format($bill_payment->amount, 2)}}</td>
            </tr>
            @php
                $totalBill_payment = $totalBill_payment + $bill_payment->amount;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{number_format($totalBill_payment, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>COBRANZAS</b></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>BOLIVARES</b></td>
        </tr>
        @php
            $totalBill_paymentBs = 0;
        @endphp
        @foreach ($bill_paymentCreditoBs as $bill_paymentB)
            <tr>
                <td colspan="2"><b>{{$bill_paymentB->type}}</b></td>
                <td colspan="2" class="end">{{number_format($bill_paymentB->amountBs, 2)}}</td>
            </tr>
            @php
                $totalBill_paymentBs = $totalBill_paymentBs + $bill_paymentB->amountBs;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{number_format($totalBill_paymentBs, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4" class="center"><b>DOLARES</b></td>
        </tr>
        @php
            $totalBill_payment = 0;
        @endphp
        @foreach ($bill_paymentsCredito as $bill_payment)
            <tr>
                <td colspan="2"><b>{{$bill_payment->type}}</b></td>
                <td colspan="2" class="end">{{number_format($bill_payment->amount, 2)}}</td>
            </tr>
            @php
                $totalBill_payment = $totalBill_payment + $bill_payment->amount;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{number_format($totalBill_payment, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>DEVOLUCIONES</b></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>BOLIVARES</b></td>
        </tr>
        @php
            $totalRepaymentBs = 0;
        @endphp
        @foreach ($repaymentBs as $repaymentB)
            <tr>
                <td colspan="2"><b>
                    @if ($repaymentB->status == 0)
                        NOTA DE CREDITO
                    @else
                        DEVOLUCIÓN
                    @endif
                </b></td>
                <td colspan="2" class="end">{{number_format($repaymentB->amountBs, 2)}}</td>
            </tr>
            @php
                $totalRepaymentBs = $totalRepaymentBs + $repaymentB->amountBs;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{number_format($totalRepaymentBs, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4" class="center"><b>DOLARES</b></td>
        </tr>
        @php
            $totalRepayment = 0;
        @endphp
        @foreach ($repayments as $repayment)
            <tr>
                <td colspan="2"><b>
                    @if ($repayment->status == 0)
                        NOTA DE CREDITO
                    @else
                        DEVOLUCIÓN
                    @endif
                </b></td>
                <td colspan="2" class="end">{{number_format($repayment->amount, 2)}}</td>
            </tr>
            @php
                $totalRepayment = $totalRepayment + $repayment->amount;
            @endphp
        @endforeach
        <tr>
            <td colspan="2" class="size"><b>TOTAL:</b></td>
            <td colspan="2" class="end size"><b>{{number_format($totalRepayment, 2)}}</b></td>
        </tr>
        <tr>
            <td colspan="4"></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
        <tr>
            <td colspan="4" class="center"><b>NOTA</b></td>
        </tr>
        <tr>
            <td colspan="4" class="puntos">....................................................................................................</td>
        </tr> 
    </table>
</body>
</html>