<!DOCTYPE html>
<html>
<head>
    <title>Catálogo de Productos</title>
    <style>
        @page {
            margin: 30px;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }
        .product {
            width: 210px; /* Ajustado al ancho de tu card */
            display: inline-block;
            margin: 5px;
            text-align: center;
            height: 290px; /* Ajustado a la altura de tu card */
            border: 1px solid #ddd; /* Opcional: añade un borde para simular la card */
            padding: 5px;
        }
        .product img {
            width: 150px;
            height: 150px;
            display: block;
            margin: 10px auto;
        }
        .product h6 {
            font-size: 12px;
            height: 60px;
            margin: 0;
            padding: 0;
        }
        .product p {
            font-size: 13px;
            margin: 0;
            padding: 0;
        }
        .product p b {
            font-size: 15px;
        }
        .h1{
            margin: auto;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="h1">
        <h1>Catálogo de Productos</h1>
    </div>
    <br><br>
    @php
        $productsArray = $productsPage->toArray();
        $chunks = array_chunk($productsArray, 9);
    @endphp
    @foreach($chunks as $chunk)
        <div class="product-grid">
            @foreach($chunk as $pro)
                <div class="product">
                    <img src="{{ public_path('storage/' . $pro['url1']) }}"
                        onerror="this.src='{{ public_path('storage/products/product.png') }}'"
                        >
                    <h6>{{ $pro['name'] }}</h6>
                    @php
                        $priceBs = $pro['price'] * $dolar->priceBs;
                        $price = $priceBs / $dolar->price;
                    @endphp
                    <p>Precio <b>$ {{ number_format($price, 2) }}</b></p>
                    <p>Precio en Bs <b>{{ number_format($priceBs, 2) }}</b></p>
                    <p>Cod. <b>{{ $pro['code'] }}</b></p>
                </div>
            @endforeach
        </div>
        @if (!$loop->last)
            <div style="page-break-after: always;"></div>
            <br><br><br><br><br><br>
        @endif
    @endforeach
</body>
</html>