<div class="row text-center"> 
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" style="padding:0;">  
        <a style="margin: -6px !important; padding: 5px;" href="javascript:void(0)" data-toggle="tooltip" onClick="modalServicePayment({{ $id }})"  data-original-title="Edit" class="edit btn btn-info"> 
            <i class="fa-regular fa-eye"  style="color: White  !important;"></i>
        </a>
    </div> 
</div> 