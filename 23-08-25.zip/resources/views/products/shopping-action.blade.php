<div class="row text-center"> 
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" style="padding:0;">  
        <a style="margin: -3px !important; padding: 5px; color:white;"  href="{{ route('pdfShopping', ['id' => $id]) }}" data-toggle="tooltip" target="_blank" data-original-title="Edit" class="edit btn btn-info"> 
            <i class="fa-regular fa-eye"></i>
        </a>
    </div>
</div>