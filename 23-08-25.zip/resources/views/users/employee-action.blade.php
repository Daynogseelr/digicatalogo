
<div class="row text-center"> 
    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6" style="padding:0;">  
        <a style="margin: -6px !important; padding: 5px;"  href="javascript:void(0)"  data-toggle="tooltip" onClick="editFunc({{ $id }})" data-original-title="Edit" class="edit btn btn-primary edit"> 
            <i class="fa-regular fa-pen-to-square"></i>
        </a>
    </div> 
    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6" style="padding:0;"> 
        <a style="margin: -6px !important; padding: 5px;" onClick="deleteEmployee({{ $id }})" data-toggle="tooltip" class="delete btn btn-danger">
            <i class="fa-solid fa-trash-can"></i>
        </a>
    </div>
</div>    

